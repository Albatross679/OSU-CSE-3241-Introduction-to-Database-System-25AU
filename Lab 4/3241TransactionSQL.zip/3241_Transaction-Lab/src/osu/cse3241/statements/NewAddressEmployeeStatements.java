package osu.cse3241.statements;

/**
 * This is the statement that will update an employee's address. It will be used
 * the in 1st transaction for this lab. The Address column in the Employee table
 * will be updated. The user can choose the employee they want to update the
 * address for.
 *
 * Remember to include the semicolon at the end of the statement strings. (Not
 * all programming languages and/or packages require the semicolon (e.g.,
 * Python's SQLite3 library))
 */
public class NewAddressEmployeeStatements {

    /*
     * PART 4: Complete the string to build the update statement that the
     * transaction will execute. The statement should update an employee's
     * address in the Employee table. EmployeeID and Address are inputed into
     * the function.
     *
     */

    /*
     * TODO
     */
    public static String updateEmployeeAddress = " ";
}