package osu.cse3241.options;

import java.util.Scanner;

import osu.cse3241.utilities.Utilities;
import osu.cse3241.sql.SQL;
import osu.cse3241.GRS;

public class SearchRecordStockCount {
	
	public static void menu(Scanner cin) {
		Utilities.printDivider();
		System.out.print("SEARCH RECORD STOCK COUNT:\n"
				+ "Input album name (or 'x' to quit): ");
		String album_name = cin.nextLine();
		
		if (!"x".equals(album_name) && !album_name.trim().isEmpty()) {
		    searchRecordStockCount();
		}
	}

	/*
	 * PART SIX:
	 * Complete the following method and remove its placeholder.
	 */
	
	/**
	 * Search record stock count by album name.
	 */
	private static void searchRecordStockCount() {
		Utilities.placeholder();
		/* TODO */
	}
	
}
