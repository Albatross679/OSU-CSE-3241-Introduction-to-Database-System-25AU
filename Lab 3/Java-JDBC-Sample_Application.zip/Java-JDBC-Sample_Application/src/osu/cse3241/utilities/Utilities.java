package osu.cse3241.utilities;

public class Utilities {
	/**
	 * Prints divider between view results.
	 */
	public static void printDivider() {
		System.out.println("-------------------------------------------------------------------");
	}
	
	/**
	 * Under construction!
	 */
	public static void placeholder() {
		System.out.println("Under construction!");
		return;
	}
}
